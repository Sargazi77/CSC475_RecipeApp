package com.example.recipe

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * DatabaseHelper is responsible for creating, managing, and interacting with the SQLite database.
 * It includes methods for adding, retrieving, updating, and deleting recipes and shopping list items.
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "recipes.db", null, 2) {

    // This method is called the first time the database is created
    override fun onCreate(db: SQLiteDatabase) {
        // Create the "recipes" table to store all recipe data
        db.execSQL(
            """
            CREATE TABLE recipes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                ingredients TEXT,
                notes TEXT,
                imageUri TEXT,
                isFavorite INTEGER DEFAULT 0
            )
            """
        )

        // Create the "shopping_list" table to store ingredients the user adds to the shopping list
        db.execSQL(
            """
            CREATE TABLE shopping_list (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item TEXT
            )
            """
        )

        // Insert a sample recipe to demonstrate how recipes are stored
        insertSampleRecipes(db)
    }

    /**
     * Inserts a sample recipe into the database. This is useful for testing and for demonstrating the app to users.
     */
    private fun insertSampleRecipes(db: SQLiteDatabase) {
        val sampleRecipe = Recipe(
            id = 0, // ID will be set automatically by the database
            name = "Breaded Pork Chops",
            ingredients = "Pork chops, bread crumbs, eggs, seasoning",
            notes = "Delicious crispy pork chops.",
            imageUri = "android.resource://com.example.recipe/drawable/breaded_pork_chops", // Placeholder image URI
            isFavorite = false // Default to non-favorite
        )
        insertRecipe(db, sampleRecipe)
    }

    /**
     * Inserts a recipe into the "recipes" table.
     * @param db SQLiteDatabase instance to interact with the database.
     * @param recipe Recipe object containing details to insert into the table.
     */
    private fun insertRecipe(db: SQLiteDatabase, recipe: Recipe) {
        val values = ContentValues().apply {
            put("name", recipe.name)
            put("ingredients", recipe.ingredients)
            put("notes", recipe.notes)
            put("imageUri", recipe.imageUri)
            put("isFavorite", if (recipe.isFavorite) 1 else 0)
        }
        db.insert("recipes", null, values) // Insert the recipe data into the "recipes" table
    }

    // Called when the database version changes, to upgrade the database structure
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS recipes") // Drop old "recipes" table
        db.execSQL("DROP TABLE IF EXISTS shopping_list") // Drop old "shopping_list" table
        onCreate(db) // Recreate the tables by calling onCreate
    }

    /**
     * Inserts a new recipe into the database.
     * @param recipe Recipe object to insert.
     * @return Boolean indicating success or failure of the insert operation.
     */
    fun insertRecipe(recipe: Recipe): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", recipe.name)
            put("ingredients", recipe.ingredients)
            put("notes", recipe.notes)
            put("imageUri", recipe.imageUri)
            put("isFavorite", if (recipe.isFavorite) 1 else 0)
        }
        return db.insert("recipes", null, values) != -1L
    }

    /**
     * Retrieves a recipe by its ID from the database.
     * @param id ID of the recipe to retrieve.
     * @return Recipe object if found, or null if not found.
     */
    fun getRecipeById(id: Int): Recipe? {
        val db = readableDatabase
        val cursor = db.query("recipes", null, "id = ?", arrayOf(id.toString()), null, null, null)

        return if (cursor.moveToFirst()) {
            // Build a Recipe object from the data in the database
            val recipe = Recipe(
                id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                name = cursor.getString(cursor.getColumnIndexOrThrow("name")),
                ingredients = cursor.getString(cursor.getColumnIndexOrThrow("ingredients")),
                notes = cursor.getString(cursor.getColumnIndexOrThrow("notes")),
                imageUri = cursor.getString(cursor.getColumnIndexOrThrow("imageUri")),
                isFavorite = cursor.getInt(cursor.getColumnIndexOrThrow("isFavorite")) == 1
            )
            cursor.close()
            recipe
        } else {
            cursor.close()
            null // Return null if no recipe was found
        }
    }

    /**
     * Retrieves all recipes from the database.
     * @return List of all Recipe objects in the database.
     */
    fun getAllRecipes(): List<Recipe> {
        val db = readableDatabase
        val cursor = db.query("recipes", null, null, null, null, null, null)

        val recipes = mutableListOf<Recipe>()
        if (cursor.moveToFirst()) {
            do {
                recipes.add(
                    Recipe(
                        id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                        name = cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        ingredients = cursor.getString(cursor.getColumnIndexOrThrow("ingredients")),
                        notes = cursor.getString(cursor.getColumnIndexOrThrow("notes")),
                        imageUri = cursor.getString(cursor.getColumnIndexOrThrow("imageUri")),
                        isFavorite = cursor.getInt(cursor.getColumnIndexOrThrow("isFavorite")) == 1
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        return recipes // Return the list of recipes
    }

    /**
     * Retrieves only the recipes marked as favorites.
     * @return List of favorite recipes.
     */
    fun getFavoriteRecipes(): List<Recipe> {
        val db = readableDatabase
        val cursor = db.query(
            "recipes",
            null,
            "isFavorite = ?",
            arrayOf("1"),
            null,
            null,
            null
        )

        val favoriteRecipes = mutableListOf<Recipe>()
        if (cursor.moveToFirst()) {
            do {
                favoriteRecipes.add(
                    Recipe(
                        id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                        name = cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        ingredients = cursor.getString(cursor.getColumnIndexOrThrow("ingredients")),
                        notes = cursor.getString(cursor.getColumnIndexOrThrow("notes")),
                        imageUri = cursor.getString(cursor.getColumnIndexOrThrow("imageUri")),
                        isFavorite = cursor.getInt(cursor.getColumnIndexOrThrow("isFavorite")) == 1
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        return favoriteRecipes
    }

    /**
     * Updates an existing recipe in the database.
     * @param recipe Recipe object with updated data.
     * @return Boolean indicating success of the update.
     */
    fun updateRecipe(recipe: Recipe): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", recipe.name)
            put("ingredients", recipe.ingredients)
            put("notes", recipe.notes)
            put("imageUri", recipe.imageUri)
            put("isFavorite", if (recipe.isFavorite) 1 else 0)
        }
        return db.update("recipes", values, "id = ?", arrayOf(recipe.id.toString())) > 0
    }

    /**
     * Toggles the favorite status of a recipe.
     * @param recipeId ID of the recipe to update.
     * @param isFavorite New favorite status.
     * @return Boolean indicating success of the update.
     */
    fun updateRecipeFavoriteStatus(recipeId: Int, isFavorite: Boolean): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("isFavorite", if (isFavorite) 1 else 0)
        }
        return db.update("recipes", values, "id = ?", arrayOf(recipeId.toString())) > 0
    }

    /**
     * Retrieves all items in the shopping list.
     * @return List of shopping list items as strings.
     */
    fun getShoppingListItems(): List<String> {
        val db = readableDatabase
        val cursor = db.query("shopping_list", null, null, null, null, null, null)

        val items = mutableListOf<String>()
        if (cursor.moveToFirst()) {
            do {
                items.add(cursor.getString(cursor.getColumnIndexOrThrow("item")))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return items
    }

    /**
     * Inserts an item into the shopping list.
     * @param item String representing the item to add.
     * @return Boolean indicating success of the insertion.
     */
    fun insertShoppingListItem(item: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("item", item)
        }
        return db.insert("shopping_list", null, values) != -1L
    }

    /**
     * Deletes an item from the shopping list.
     * @param item String representing the item to delete.
     * @return Boolean indicating success of the deletion.
     */
    fun deleteShoppingListItem(item: String): Boolean {
        val db = writableDatabase
        return db.delete("shopping_list", "item = ?", arrayOf(item)) > 0
    }

    /**
     * Deletes a recipe from the database by ID.
     * @param id ID of the recipe to delete.
     * @return Boolean indicating success of the deletion.
     */
    fun deleteRecipe(id: Int): Boolean {
        val db = writableDatabase
        val result = db.delete("recipes", "id = ?", arrayOf(id.toString()))
        return result > 0
    }
}